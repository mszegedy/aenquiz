#!/bin/perl

open my $dictionary, "<", "latin-small.tsv";
open my $outfile, ">", "latin-small-nomacrons.tsv";
while(!eof $dictionary) {
  my $line = readline $dictionary;
  $line =~ s/ā/a/g;
  $line =~ s/ē/e/g;
  $line =~ s/ī/i/g;
  $line =~ s/ō/o/g;
  $line =~ s/ū/u/g;
  print $outfile $line;
}
