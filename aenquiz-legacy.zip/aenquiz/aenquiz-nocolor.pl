#!/bin/perl

# aenquiz v1.9.2. For memorizing words from the Aeneid.
# Copyright (C) 2014  Michael Szegedy
#
# This file is part of aenquiz.
#
# aenquiz is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# aenquiz is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with aenquiz.  If not, see <http://www.gnu.org/licenses/>.

use strict;
use warnings;

sub getknown {
  my $word = shift @_;
  if(!$word) {
    return 1;
  }
  my $result = open my $known, "<", "resources/known.csv";
  if(!$result) {
    return 1;
  }
  while(!eof $known) {
    my $line = readline $known;
    chomp $line;
    $line =~ m/^\s*([A-Za-z ]+?)\s*,\s*(\d+?)\s*$/;
    if($1 eq $word) {
      return $2;
    }
  }
  return 1;
}

sub getdefinition {
  my $word = shift @_;
  my @definitions = ();
  my $result = open my $dictionary, "<", ($^O eq "MSWin32") ? "resources/latin-small-nomacrons.tsv" : "resources/latin-small.tsv";
  if(!$result) {
    die "Cannot open dictionary: ".$!;
  }
  my $wasmatch = 0;
  while(!eof $dictionary) {
    my $line = readline $dictionary;
    chomp $line;
    if($line =~ m/^$word\t/) {
      $wasmatch = 1;
      $line =~ m/^(\S+)\t(\S+|Proper noun)\t# ?(.*)$/;
      if($2 && $3) {
        push @definitions, [$2,$3];
      }
    }
    elsif($wasmatch) {
      last;
    }
  }
  return @definitions;
}

sub showword {
  my %currentwords = %{ shift @_ };
  my $word = shift @_;
  print $word.":\n";
  foreach my $definition (@{ $currentwords{$word}->[1] }) {
    $definition->[1] =~ m/^(\s*)/;
    if(!($1 eq "\t")) {
      print $definition->[0]."; ";
    }
    if($definition->[1] =~ m/{{context\|[^}]*}}/) {
      $definition->[1] =~ m/({{context\|[^}]*}})/;
      my $context = $1;
      $context =~ s/{{context\||\|*}}//g;
      $context =~ s/\|/, /g;
      $context = "(".$context.") ";
      $definition->[1] =~ s/{{context\|[^}]*}}//g;
      $definition->[1] =~ s/^(\s*)//;
      if($1) {
        print substr $1, 0, -1;
      }
      print $context;
    }
    print $definition->[1]."\n";
  }
  <STDIN>;
}

sub updateknown {
  my $word = shift @_;
  my $result = open my $inknown, "<", "resources/known.csv";
  my %timesknown = ();
  if($result) {
    while(!eof $inknown) {
      my $line = readline $inknown;
      chomp $line;
      $line =~ m/^\s*([A-Za-z ]+?)\s*,\s*(\d+?)\s*$/;
      $timesknown{$1} = $2;
    }
  }
  if(exists $timesknown{$word}) {
    $timesknown{$word} += 1;
  }
  else {
    $timesknown{$word} = 1;
  }
  close $inknown;
  open my $outknown, ">", "resources/known.csv";
  foreach my $k (sort keys %timesknown) {
    print $outknown $k.",".$timesknown{$k}."\n";
  }
  close $outknown;
}

system $^O eq 'MSWin32' ? 'cls' : 'clear';
my $beginning = <<END;
aenquiz v1.9.2, Copyright (C) 2014  Michael Szegedy
This program comes with ABSOLUTELY NO WARRANTY; for details type
`warranty' at the lines dialogue.
This is free software, and you are welcome to redistribute it
under certain conditions; type `conditions' at the lines dialogue
for details.

Type QUIT at any time to quit.

END
print $beginning;
my @words = ();
my $backupresponse = "n";
my $response = "n";
if(-T "resources/backup.session") {
  print "A backup from an unexpectedly quit session exists. Do you want to load it,\ndelete it, save it as a session file, save it as a session file and then load\nit, or do nothing? (L/d/s/sl/*)\n";
  $backupresponse = <STDIN>;
  chomp $backupresponse;
}
if(-T "resources/save.session" && !(lc $backupresponse eq "l" || lc $backupresponse eq "s" || lc $backupresponse eq "sl" || $backupresponse eq "QUIT" || $backupresponse eq "")) {
  print "A session file for a previous session exists. Do you want to load it, delete it, or do nothing? (L/d/*)\n";
  $response = <STDIN>;
  chomp $response;
}
if(lc $backupresponse eq "l" || $backupresponse eq "") {
  my $result = open my $backup, "<", "resources/backup.session";
  if(!$result) {
    die "Cannot open save because: ".$!;
  }
  @words = split(", ", readline $backup);
}
elsif(lc $backupresponse eq "s" || $backupresponse eq "sl" || $backupresponse eq "") {
  my $result = open my $backup, "<", "resources/backup.session";
  if(!$result) {
    die "Cannot open save because: ".$!;
  }
  open my $save, ">", "resources/save.session";
  print $save readline $backup;
}
elsif(lc $response eq "l" || lc $backupresponse eq "sl" || $response eq "") {
  my $result = open my $save, "<", "resources/save.session";
  if(!$result) {
    die "Cannot open save because: ".$!;
  }
  @words = split(", ", readline $save);
}
elsif($backupresponse eq "QUIT" || $response eq "QUIT") {
  exit 0;
}
else {
  if(lc $backupresponse eq "d") {
    unlink "resources/backup.session";
  }
  if(lc $response eq "d") {
    unlink "resources/save.session";
  }
  my $result = open my $file, "<", "resources/aeneid-1.txt";
  if(!$result) {
    die "Cannot open Aeneid because: ".$!;
  }
  print "What line numbers would you like to be quizzed on?\n";
  my $linens = <STDIN>;
  chomp $linens;
  if($linens eq "QUIT") {
    exit 0;
  }
  if($linens eq "warranty") {
    my $warranty = <<END;
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
END
    print $warranty;
    exit 0;
  }
  if($linens eq "conditions") {
    my $conditions = <<END;
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
END
    print $conditions;
    exit 0;
  }
  if(!($linens =~ m/^([0-9]+)-([0-9]+)$/) || $1 > $2) {
    while(!($linens =~ m/^([0-9]+)-([0-9]+)$/) || $1 > $2) {
      print "Your input was not formatted correctly. Please write it in the form of a-b,\nwhere b is a number greater than or equal to a, also a number.\n";
      $linens = <STDIN>;
      chomp $linens;
      if($linens eq "QUIT") {
        exit 0;
      }
    }
  }
  $linens =~ m/^([0-9]+)-([0-9]+)$/;
  my $firstlinen = $1;
  my $lastlinen = ($2, 756)[$2 > 756];
  print "Copying words to memory...\n";
  # Read in words from text
  my $linecount = 1;
  while($linecount <= $lastlinen) {
    my $line = readline $file;
    if($linecount >= $firstlinen) {
      chomp $line;
      my @linewords = split(" ", $line);
      foreach my $word (@linewords) {
        $word =~ s/[\.,;!\?"'`\(\)\[\]]//g;
        if(!($word eq lc $word)) {
          push @linewords, lc $word;
        }
      }
      push @words, @linewords;
    }
    $linecount += 1;
  }
}
# Eliminate duplicates from @words
print "Verifying words...\n";
my %seen = ();
my @wordscopy = ();
foreach my $word (@words) {
  if(!(exists $seen{$word})) {
    push @wordscopy, $word;
    $seen{$word} = 1;
  }
}
undef %seen;
undef @words;
my $wordcount = 0;
my $wordslen = scalar @wordscopy;
my %queries = ();
foreach my $word (@wordscopy) {
  print "\rCopying definitions to memory... done with ".$wordcount."/".$wordslen." words.";
  my @definition = getdefinition($word);
  if(!(scalar @definition == 0)) {
    $queries{$word} = \@definition;
  }
  if((substr $word, -3) eq "que") {
    $word = substr $word, 0, -3;
    my @definition = getdefinition($word);
    if(!(scalar @definition == 0)) {
      $queries{$word} = \@definition;
    }
  }
  if((substr $word, -2) eq "ne" || (substr $word, -2) eq "ve") {
    $word = substr $word, 0, -2;
    my @definition = getdefinition($word);
    if(!(scalar @definition == 0)) {
      $queries{$word} = \@definition;
    }
  }
  $wordcount += 1;
}
print "\rCopying definitions to memory... done with ".$wordcount."/".$wordslen." words.\n";
# Build list of definitions
my %toquiz = ();
# Each word in %toquiz maps to an array that contains the score the user has
# achieved for that word, and an array of definitions for that word.
print "Formatting definitions...";
$wordcount = 0;
$wordslen = scalar keys %queries;
foreach my $word (keys %queries) {
  print "\rFormatting definitions... done with ".$wordcount."/".$wordslen." words.";
  my @definitionscopy = @{ $queries{$word} };
  my @definitions = ();
  my %seenverbs = ();
  foreach my $definition (@definitionscopy) {
    push @definitions, $definition;
    if(!($^O eq "MSWin32")) {
      if($definition->[1] =~ m/(conjugation|inflection|alternative form) of\|([a-zāēīōū]+)/) {
        $definition->[1] =~ m/(conjugation|inflection|alternative form) of\|([a-zāēīōū]+)/;
        my $verb = $2;
        $verb =~ s/ā/a/g;
        $verb =~ s/ē/e/g;
        $verb =~ s/ī/i/g;
        $verb =~ s/ō/o/g;
        $verb =~ s/ū/u/g;
        if(!(exists $seenverbs{$verb})) {
          $seenverbs{$verb} = 1;
          my @verbdefinitions = getdefinition($verb);
          foreach my $verbdefinition (@verbdefinitions) {
            $verbdefinition->[1] = "\t".$verbdefinition->[1];
          }
          push @definitions, @verbdefinitions;
        }
      }
    }
    else {
      if($definition->[1] =~ m/(conjugation|inflection|alternative form) of\|([a-z]+)/) {
        $definition->[1] =~ m/(conjugation|inflection|alternative form) of\|([a-z]+)/;
        my $verb = $2;
        if(!(exists $seenverbs{$verb})) {
          $seenverbs{$verb} = 1;
          my @verbdefinitions = getdefinition($verb);
          foreach my $verbdefinition (@verbdefinitions) {
            $verbdefinition->[1] = "\t".$verbdefinition->[1];
          }
          push @definitions, @verbdefinitions;
        }
      }
    }
  }
  $toquiz{$word} = [0, \@definitions];
  $wordcount += 1;
}
print "\rFormatting definitions... done with ".$wordslen."/".$wordslen." words.";
$wordslen = scalar keys %toquiz;
undef @wordscopy;
undef $wordcount;
# Begin quizzing
my %currentwords = ();
system $^O eq 'MSWin32' ? 'cls' : 'clear';
while((scalar keys %currentwords) < 10 && scalar keys %toquiz > 0) {
  my $k = (keys %toquiz)[rand keys(%toquiz)];
  my $v = delete $toquiz{$k};
  if(rand() < 1./getknown($k)) {
    $currentwords{$k} = $v;
    showword(\%currentwords, $k);
  }
}
system $^O eq 'MSWin32' ? 'cls' : 'clear';
while((scalar keys %currentwords) + (scalar keys %toquiz) > 0) {
  my $word = (keys %currentwords)[rand keys %currentwords];
  print "What is the meaning of \"".$word."\"?\n";
  my $response = <STDIN>;
  chomp $response;
  my $matchn = 0;
  foreach my $phrase (split(",", $response)) {
    $phrase =~ m/\s*(.*)\s*/g;
    if(grep {$_ =~ m/\Q$1\E/} map {$_->[1]} @{ $currentwords{$word}->[1] }) {
      $matchn += 1;
    }
  }
  if($response eq "QUIT") {
    print "Do you want to save your session? (Y/n)\n";
    $response = <STDIN>;
    chomp $response;
    if(((substr $response, 0, 1) eq "y") || ((substr $response, 0, 1) eq "Y") || $response eq "") {
      open my $save, ">", "resources/save.session";
      print $save join(", ", keys %toquiz, keys %currentwords);
    }
    print "You memorized ".($wordslen-((scalar keys %currentwords)+(scalar keys %toquiz)))."/".$wordslen." words.\n";
    if(-e "resources/backup.session") {
      unlink "resources/backup.session";
    }
    exit 0;
  }
  elsif($matchn == scalar split(",", $response) && length $response >= 1) {
    $currentwords{$word}->[0] += 1;
    if($currentwords{$word}->[0] >= 4) {
      updateknown($word);
      delete $currentwords{$word};
      if(scalar keys %toquiz) {
        my $k;
        my $v;
        while((!$k || rand() > 1./getknown($k)) && scalar keys %toquiz) {
          $k = (keys %toquiz)[rand keys %toquiz];
          $v = delete $toquiz{$k};
        }
        $currentwords{$k} = $v;
        system $^O eq 'MSWin32' ? 'cls' : 'clear';
        showword(\%currentwords, $k);
        system $^O eq 'MSWin32' ? 'cls' : 'clear';
        open my $backup, ">", "resources/backup.session";
        print $backup join(", ", keys %toquiz, keys %currentwords);
      }
    }
  }
  else {
    if($currentwords{$word}->[0] > -2) {
      $currentwords{$word}->[0] -= 1;
    }
    system $^O eq 'MSWin32' ? 'cls' : 'clear';
    showword(\%currentwords, $word);
    system $^O eq 'MSWin32' ? 'cls' : 'clear';
  }
}
print "Congratulations. You memorized all ".$wordslen." words.";
if(-T "resources/save.session") {
  print " A session file for a previous session exists. Do you want to delete it? (Y/n)\n";
  my $response = <STDIN>;
  chomp $response;
  if(lc $response eq "y" || $response eq "") {
    unlink "resources/save.session";
  }
  elsif($response eq "QUIT") {
    exit 0;
  }
}
else {
  print "\n";
}
if(-e "resources/backup.session") {
  unlink "resources/backup.session";
}
